package com.example.spk_saw

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
