import 'package:cloud_firestore/cloud_firestore.dart';

class Employee {
  final String id;
  final String name;
  final String nip;
  final String photoUrl;
  final String position;
  final double productivity;
  final String violation;
  final String attitude;
  final String creativity;
  final bool supervisorApproved;
  final bool directorApproved;

  Employee({
    required this.id,
    required this.name,
    required this.nip,
    required this.photoUrl,
    required this.position,
    required this.productivity,
    required this.violation,
    required this.attitude,
    required this.creativity,
    required this.supervisorApproved,
    required this.directorApproved,
  });

  factory Employee.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Employee(
      id: doc.id,
      name: data['name'] ?? '',
      nip: data['nip'] ?? '',
      photoUrl: data['photoUrl'] ?? '',
      position: data['position'] ?? '',
      productivity: (data['productivity'] ?? 0).toDouble(),
      violation: data['violation'] ?? 'Tidak ada SP',
      attitude: data['attitude'] ?? 'Cukup',
      creativity: data['creativity'] ?? 'Cukup',
      supervisorApproved: data['supervisorApproved'] ?? false,
      directorApproved: data['directorApproved'] ?? false,
    );
  }
}