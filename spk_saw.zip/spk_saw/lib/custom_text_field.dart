import 'package:flutter/material.dart';

import '../theme.dart';

class CustomTextField extends StatelessWidget {
  final String nameTextField;
  final Widget iconTextField;
  final TextEditingController controller;
  final bool isPassword;
  final bool isEnabled;
  final TextInputType keyboardType;

  const CustomTextField({
    Key? key,
    required this.nameTextField,
    required this.iconTextField,
    required this.controller,
    this.isEnabled = true,
    this.isPassword = false,
    required this.keyboardType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(
        bottom: 20.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            keyboardType: keyboardType,
            cursorColor: Colors.green,
            enabled: isEnabled,
            controller: controller,
            obscureText: isPassword,
            decoration: InputDecoration(
              hintText: nameTextField,
              hintStyle: kBlackTextStyle.copyWith(
                fontWeight: regular,
                fontSize: 16,
                color: isEnabled
                    ? const Color.fromARGB(255, 159, 158, 158)
                    : Colors.green,
              ),
              filled: true,
              fillColor: kSemiBlackColor,
              suffixIcon: iconTextField,
              suffixIconColor: const Color.fromARGB(255, 124, 126, 124),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(
                  width: 1,
                  color: Colors.white,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              border: OutlineInputBorder(
                borderSide: const BorderSide(
                  width: 0,
                  style: BorderStyle.none,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
