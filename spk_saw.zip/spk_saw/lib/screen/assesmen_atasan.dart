import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:spk_saw/theme.dart';

import 'assesment_page.dart';
import 'login_page.dart';

class AssessmentAtasan extends StatefulWidget {
  final String userNIP;

  const AssessmentAtasan({super.key, required this.userNIP});

  @override
  _AssessmentAtasanState createState() => _AssessmentAtasanState();
}

class _AssessmentAtasanState extends State<AssessmentAtasan> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";
  // bool isDirector = false;

  @override
  void initState() {
    super.initState();
    // _checkUserRole();
  }

  // void _checkUserRole() async {
  //   final userDoc = await FirebaseFirestore.instance
  //       .collection('users')
  //       .where('nip', isEqualTo: widget.userNIP)
  //       .get();

  //   if (userDoc.docs.isNotEmpty) {
  //     setState(() {
  //       isDirector = userDoc.docs.first['nip'] == 'direktur';
  //     });
  //   }
  // }

  void _handleApprove(Employee employee) async {
    try {
      await FirebaseFirestore.instance
          .collection('employees')
          .doc(employee.id)
          .update({
        if (widget.userNIP == 'direktur')
          'directorApproved': true
        else
          'supervisorApproved': true,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Assessment berhasil diapprove'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _handleCancelApproval(Employee employee) async {
    // Show confirmation dialog
    bool? confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Konfirmasi Pembatalan'),
          content: Text('Apakah Anda yakin ingin membatalkan approval?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
              child: Text('Ya, Batalkan'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    try {
      await FirebaseFirestore.instance
          .collection('employees')
          .doc(employee.id)
          .update({
        if (widget.userNIP == 'direktur')
          'directorApproved': false
        else
          'supervisorApproved': false,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Approval berhasil dibatalkan'),
          backgroundColor: Colors.orange,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Widget _buildActionButton(Employee employee) {
    bool isSupervisorApproved = employee.supervisorApproved;
    bool isDirectorApproved = employee.directorApproved;

    if (widget.userNIP == 'direktur') {
      // Logic for Director
       if (isDirectorApproved) {
        return ElevatedButton(
          onPressed: () => _handleCancelApproval(employee),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            padding: EdgeInsets.symmetric(horizontal: 16),
          ),
          child: Text('Cancel\nApproval'),
        );
      } else {
        return ElevatedButton(
          onPressed: () => _handleApprove(employee),
          style: ElevatedButton.styleFrom(
            backgroundColor: kGreenColor,
            padding: EdgeInsets.symmetric(horizontal: 16),
          ),
          child: Text('Approve'),
        );
      }
    } else {
      // Logic for Supervisor
      if (isSupervisorApproved) {
        return ElevatedButton(
          onPressed: () => _handleCancelApproval(employee),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            padding: EdgeInsets.symmetric(horizontal: 16),
          ),
          child: Text('Cancel\nApproval'),
        );
      } else {
        return ElevatedButton(
          onPressed: () => _handleApprove(employee),
          style: ElevatedButton.styleFrom(
            backgroundColor: kGreenColor,
            padding: EdgeInsets.symmetric(horizontal: 16),
          ),
          child: Text('Approve'),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.userNIP == 'direktur' ? 'Director Approval' : 'Supervisor Approval',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: kGreenColor,
        actions: [
          IconButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              },
              icon: Icon(Icons.logout))
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search by name or NIP',
                prefixIcon: Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('employees')
                  .orderBy('name')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                List<Employee> employees = snapshot.data!.docs
                    .map((doc) => Employee.fromFirestore(doc))
                    .where((employee) =>
                        employee.name.toLowerCase().contains(_searchQuery) ||
                        employee.nip.toLowerCase().contains(_searchQuery))
                    .toList();

                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: [
                      DataColumn(label: Text('Actions')),
                      DataColumn(label: Text('Name')),
                      DataColumn(label: Text('NIP')),
                      DataColumn(label: Text('Productivity')),
                      DataColumn(label: Text('Violation')),
                      DataColumn(label: Text('Attitude')),
                      DataColumn(label: Text('Creativity')),
                      DataColumn(label: Text('Supervisor\nApproval')),
                      DataColumn(label: Text('Director\nApproval')),
                    ],
                    rows: employees.map((employee) {
                      return DataRow(cells: [
                        DataCell(_buildActionButton(employee)),
                        DataCell(Text(employee.name)),
                        DataCell(Text(employee.nip)),
                        DataCell(
                            Text(employee.productivity.toStringAsFixed(2))),
                        DataCell(Text(employee.violation)),
                        DataCell(Text(employee.attitude)),
                        DataCell(Text(employee.creativity)),
                        DataCell(
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: employee.supervisorApproved
                                  ? Colors.green[100]
                                  : Colors.red[100],
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              employee.supervisorApproved
                                  ? 'Approved'
                                  : 'Pending',
                              style: TextStyle(
                                color: employee.supervisorApproved
                                    ? Colors.green[800]
                                    : Colors.red[800],
                              ),
                            ),
                          ),
                        ),
                        DataCell(
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: employee.directorApproved
                                  ? Colors.green[100]
                                  : Colors.red[100],
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              employee.directorApproved
                                  ? 'Approved'
                                  : 'Pending',
                              style: TextStyle(
                                color: employee.directorApproved
                                    ? Colors.green[800]
                                    : Colors.red[800],
                              ),
                            ),
                          ),
                        ),
                      ]);
                    }).toList(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
