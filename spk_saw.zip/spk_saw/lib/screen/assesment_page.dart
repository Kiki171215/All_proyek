import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:spk_saw/theme.dart';

class AssessmentPage extends StatefulWidget {
  const AssessmentPage({super.key});

  @override
  _AssessmentPageState createState() => _AssessmentPageState();
}

class _AssessmentPageState extends State<AssessmentPage> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Employee Assessment',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: kGreenColor,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search by name or NIP',
                prefixIcon: Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('employees')
                  .orderBy('name')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                List<Employee> employees = snapshot.data!.docs
                    .map((doc) => Employee.fromFirestore(doc))
                    .where((employee) =>
                        employee.name.toLowerCase().contains(_searchQuery) ||
                        employee.nip.toLowerCase().contains(_searchQuery))
                    .toList();

                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: [
                      DataColumn(label: Text('Actions')),
                      DataColumn(label: Text('Name')),
                      DataColumn(label: Text('NIP')),
                      DataColumn(label: Text('Productivity')),
                      DataColumn(label: Text('Violation')),
                      DataColumn(label: Text('Attitude')),
                      DataColumn(label: Text('Creativity')),
                      DataColumn(label: Text('Supervisor\nApproval')),
                      DataColumn(label: Text('Director\nApproval')),
                    ],
                    rows: employees.map((employee) {
                      return DataRow(cells: [
                        DataCell(IconButton(
                          icon: Icon(Icons.edit, color: kGreenColor),
                          onPressed: () => _showEditDialog(context, employee),
                        )),
                        DataCell(Text(employee.name)),
                        DataCell(Text(employee.nip)),
                        DataCell(
                            Text(employee.productivity.toStringAsFixed(2))),
                        DataCell(Text(employee.violation)),
                        DataCell(Text(employee.attitude)),
                        DataCell(Text(employee.creativity)),
                        DataCell(
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: employee.supervisorApproved
                                  ? Colors.green[100]
                                  : Colors.red[100],
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              employee.supervisorApproved
                                  ? 'Approved'
                                  : 'Pending',
                              style: TextStyle(
                                color: employee.supervisorApproved
                                    ? Colors.green[800]
                                    : Colors.red[800],
                              ),
                            ),
                          ),
                        ),
                        DataCell(
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: employee.directorApproved
                                  ? Colors.green[100]
                                  : Colors.red[100],
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              employee.directorApproved
                                  ? 'Approved'
                                  : 'Pending',
                              style: TextStyle(
                                color: employee.directorApproved
                                    ? Colors.green[800]
                                    : Colors.red[800],
                              ),
                            ),
                          ),
                        ),
                      ]);
                    }).toList(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showEditDialog(BuildContext context, Employee employee) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Assessment for ${employee.name}'),
          content: SingleChildScrollView(
            child: AssessmentForm(employee: employee),
          ),
        );
      },
    );
  }
}

class AssessmentForm extends StatefulWidget {
  final Employee employee;

  AssessmentForm({required this.employee});

  @override
  _AssessmentFormState createState() => _AssessmentFormState();
}

class _AssessmentFormState extends State<AssessmentForm> {
  final _formKey = GlobalKey<FormState>();
  late double _productivity;
  String _violation = 'Tidak ada SP';
  String _attitude = 'Cukup';
  String _creativity = 'Cukup';
  late bool _supervisorApproved;
  late bool _directorApproved;
  // Dropdown values
  String _selectedPresensi = '40 jam';
  String _selectedTarget = '5 target';

  final List<String> _violationOptions = ['Tidak ada SP', 'SP1', 'SP2', 'SP3'];
  final List<String> _attitudeOptions = [
    'Kurang',
    'Cukup',
    'Baik',
    'Sangat Baik'
  ];
  final List<String> _creativityOptions = [
    'Kurang',
    'Cukup',
    'Baik',
    'Sangat Baik'
  ];

  // Options for dropdowns
  final List<String> _presensiOptions = [
    '< 40 jam',
    '40 jam',
    '40-41 jam',
    '> 41 jam'
  ];

  final List<String> _targetOptions = ['< 5 target', '5 target', '> 5 target'];

  // Scoring maps
  final Map<String, double> _presensiScores = {
    '< 40 jam': 25.0,
    '40 jam': 50.0,
    '40-41 jam': 75.0,
    '> 41 jam': 100.0
  };

  final Map<String, double> _targetScores = {
    '< 5 target': 25.0,
    '5 target': 50.0,
    '> 5 target': 100.0
  };

  // Rating maps
  final Map<String, String> _presensiRatings = {
    '< 40 jam': 'Kurang',
    '40 jam': 'Cukup',
    '40-41 jam': 'Baik',
    '> 41 jam': 'Sangat Baik'
  };

  final Map<String, String> _targetRatings = {
    '< 5 target': 'Buruk',
    '5 target': 'Cukup',
    '> 5 target': 'Baik'
  };
  @override
  void initState() {
    super.initState();
    _productivity = widget.employee.productivity;
    _violation = widget.employee.violation;
    _attitude = widget.employee.attitude;
    _creativity = widget.employee.creativity;
    _supervisorApproved = widget.employee.supervisorApproved;
    _directorApproved = widget.employee.directorApproved;
  }

  // Calculate final productivity score
  double _calculateProductivity() {
    double presensiScore = _presensiScores[_selectedPresensi] ?? 50.0;
    double targetScore = _targetScores[_selectedTarget] ?? 50.0;
    return (presensiScore * 0.6) + (targetScore * 0.4);
  }

  // Determine presensi rating based on hours
  String _getPresensiRating(double hours) {
    if (hours < 40) return 'Kurang';
    if (hours == 40) return 'Cukup';
    if (hours <= 41) return 'Baik';
    return 'Sangat Baik';
  }

  // Determine target rating based on value
  String _getTargetRating(double value) {
    if (value < 5) return 'Buruk';
    if (value == 5) return 'Cukup';
    return 'Baik';
  }

  Widget _buildScoreCard(
      String title, String rating, double score, Color color) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                rating,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 8),
            Text(
              '${score.toStringAsFixed(0)} points',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double presensiScore = _presensiScores[_selectedPresensi] ?? 50.0;
    double targetScore = _targetScores[_selectedTarget] ?? 50.0;
    _productivity = _calculateProductivity();
    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Card(
            elevation: 4,
            margin: EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Penilaian Produktivitas',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 16),
                  // Presensi Dropdown
                  DropdownButtonFormField<String>(
                    value: _selectedPresensi,
                    decoration: InputDecoration(
                      labelText: 'Jam Kerja per Minggu',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.access_time),
                    ),
                    items: _presensiOptions.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      if (newValue != null) {
                        setState(() {
                          _selectedPresensi = newValue;
                        });
                      }
                    },
                  ),
                  SizedBox(height: 16),
                  // Target Dropdown
                  DropdownButtonFormField<String>(
                    value: _selectedTarget,
                    decoration: InputDecoration(
                      labelText: 'Target/Realisasi',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.track_changes),
                    ),
                    items: _targetOptions.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      if (newValue != null) {
                        setState(() {
                          _selectedTarget = newValue;
                        });
                      }
                    },
                  ),
                ],
              ),
            ),
          ),

          // Score Cards
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            child: Row(
              children: [
                Expanded(
                  child: _buildScoreCard(
                    'Presensi (60%)',
                    _presensiRatings[_selectedPresensi] ?? 'Cukup',
                    presensiScore,
                    Colors.blue,
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: _buildScoreCard(
                    'Target (40%)',
                    _targetRatings[_selectedTarget] ?? 'Cukup',
                    targetScore,
                    Colors.green,
                  ),
                ),
              ],
            ),
          ),

          // Final Score Card
          Card(
            elevation: 4,
            color: Colors.blue[50],
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    'Final Productivity Score',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '${_productivity.toStringAsFixed(1)}%',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[700],
                    ),
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 24),

          DropdownButtonFormField<String>(
            value: _violation,
            decoration: InputDecoration(labelText: 'Pelanggaran Berat'),
            items: _violationOptions.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _violation = newValue!;
              });
            },
          ),
          DropdownButtonFormField<String>(
            value: _attitude,
            decoration: InputDecoration(labelText: 'Attitude'),
            items: _attitudeOptions.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _attitude = newValue!;
              });
            },
          ),
          DropdownButtonFormField<String>(
            value: _creativity,
            decoration: InputDecoration(labelText: 'Kreativitas'),
            items: _creativityOptions.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? newValue) {
              setState(() {
                _creativity = newValue!;
              });
            },
          ),
          SwitchListTile(
            title: Text('Supervisor Approval'),
            value: _supervisorApproved,
            onChanged: (bool value) {
              setState(() {
                _supervisorApproved = value;
              });
            },
          ),
          SwitchListTile(
            title: Text('Director Approval'),
            value: _directorApproved,
            onChanged: (bool value) {
              setState(() {
                _directorApproved = value;
              });
            },
          ),
          SizedBox(height: 20),
          ElevatedButton(
            child: Text('Save Changes'),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                _formKey.currentState!.save();
                _updateEmployee();
                Navigator.of(context).pop();
              }
            },
          ),
        ],
      ),
    );
  }

  void _updateEmployee() {
    FirebaseFirestore.instance
        .collection('employees')
        .doc(widget.employee.id)
        .update({
      'productivity': _productivity,
      'violation': _violation,
      'attitude': _attitude,
      'creativity': _creativity,
      'supervisorApproved': _supervisorApproved,
      'directorApproved': _directorApproved,
    });
  }
}

class Employee {
  final String id;
  final String name;
  final String nip;
  final String photoUrl;
  final String position;
  final double productivity;
  final String violation;
  final String attitude;
  final String creativity;
  final bool supervisorApproved;
  final bool directorApproved;

  Employee({
    required this.id,
    required this.name,
    required this.nip,
    required this.photoUrl,
    required this.position,
    required this.productivity,
    required this.violation,
    required this.attitude,
    required this.creativity,
    required this.supervisorApproved,
    required this.directorApproved,
  });

  factory Employee.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Employee(
      id: doc.id,
      name: data['name'] ?? '',
      nip: data['nip'] ?? '',
      photoUrl: data['photoUrl'] ?? '',
      position: data['position'] ?? '',
      productivity: (data['productivity'] ?? 0).toDouble(),
      violation: data['violation'] ?? 'Tidak ada SP',
      attitude: data['attitude'] ?? 'Cukup',
      creativity: data['creativity'] ?? 'Cukup',
      supervisorApproved: data['supervisorApproved'] ?? false,
      directorApproved: data['directorApproved'] ?? false,
    );
  }
}
