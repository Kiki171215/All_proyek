import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spk_saw/theme.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  Future<Employee?> _fetchEmployee() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? nip = prefs.getString('nip');

      debugPrint("nip nya $nip");

      if (nip != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('employees')
            .where('nip', isEqualTo: nip)
            .get();

        if (userDoc.docs.isNotEmpty) {
          return Employee.fromFirestore(userDoc.docs.first);
        }
      }
      return null;
    } catch (e) {
      print('Error fetching employee: $e');
      return null;
    }
  }

  Widget _buildProfileImage(String imageUrl) {
    return Container(
      width: 120,
      height: 120,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: kGreenColor,
          width: 3,
        ),
      ),
      child: ClipOval(
        child: imageUrl.isNotEmpty
            ? Image.network(
                imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: Colors.grey[200],
                    child: Icon(
                      Icons.person,
                      size: 60,
                      color: Colors.grey[400],
                    ),
                  );
                },
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return Center(
                    child: CircularProgressIndicator(
                      value: loadingProgress.expectedTotalBytes != null
                          ? loadingProgress.cumulativeBytesLoaded /
                              loadingProgress.expectedTotalBytes!
                          : null,
                    ),
                  );
                },
              )
            : Container(
                color: Colors.grey[200],
                child: Icon(
                  Icons.person,
                  size: 60,
                  color: Colors.grey[400],
                ),
              ),
      ),
    );
  }

  Widget _buildProfileContent(Employee employee) {
    return Center(
      child: SingleChildScrollView(
        child: Container(
          constraints: BoxConstraints(maxWidth: 600),
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              _buildProfileImage(employee.photoUrl),
              SizedBox(height: 20),
              SelectableText(
                employee.name,
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: kGreenColor,
                ),
              ),
              SizedBox(height: 8),
              SelectableText(
                'NIP: ${employee.nip}',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  color: Colors.grey.shade700,
                ),
              ),
              SizedBox(height: 16),
              Card(
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                child: ListTile(
                  leading: Icon(Icons.work, color: kGreenColor),
                  title: SelectableText(
                    employee.position,
                    style: GoogleFonts.poppins(
                      fontSize: 20,
                      color: Colors.green.shade700,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorWidget(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 60,
              color: Colors.red.shade300,
            ),
            SizedBox(height: 16),
            Text(
              message,
              style: GoogleFonts.poppins(
                color: Colors.grey[700],
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: kGreenColor),
          SizedBox(height: 16),
          Text(
            'Loading profile...',
            style: GoogleFonts.poppins(
              color: Colors.grey[600],
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Profile',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: kGreenColor,
      ),
      body: FutureBuilder<Employee?>(
        future: _fetchEmployee(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _buildLoadingWidget();
          }

          if (snapshot.hasError) {
            return _buildErrorWidget('Error loading profile: ${snapshot.error}');
          }

          if (!snapshot.hasData || snapshot.data == null) {
            return _buildErrorWidget('User profile not found');
          }

          return _buildProfileContent(snapshot.data!);
        },
      ),
    );
  }
}

class Employee {
  final String id;
  final String name;
  final String nip;
  final String photoUrl;
  final String position;

  Employee({
    required this.id,
    required this.name,
    required this.nip,
    required this.photoUrl,
    required this.position,
  });

  factory Employee.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Employee(
      id: doc.id,
      name: data['name'] ?? '',
      nip: data['nip'] ?? '',
      photoUrl: data['photoUrl'] ?? '',
      position: data['position'] ?? '',
    );
  }
}