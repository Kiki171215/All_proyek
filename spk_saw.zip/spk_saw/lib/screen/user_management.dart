import 'dart:io';
import 'package:bcrypt/bcrypt.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spk_saw/theme.dart';
import 'package:uuid/uuid.dart';
import 'package:google_fonts/google_fonts.dart';

class ImageData {
  final dynamic file; // File for mobile, Uint8List for web
  final String path;
  final bool isWeb;

  ImageData({
    required this.file,
    required this.path,
    required this.isWeb,
  });
}

class Employee {
  final String id;
  final String name;
  final String nip;
  final String photoUrl;
  final String position;
  final String passwordHash; // New field for password hash

  Employee({
    required this.id,
    required this.name,
    required this.nip,
    required this.photoUrl,
    required this.position,
    required this.passwordHash,
  });

  factory Employee.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Employee(
      id: doc.id,
      name: data['name'] ?? '',
      nip: data['nip'] ?? '',
      photoUrl: data['photoUrl'] ?? '',
      position: data['position'] ?? '',
      passwordHash: data['passwordHash'] ?? '',
    );
  }
}

class UserManagementPage extends StatelessWidget {
  const UserManagementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Management',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: kGreenColor,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('employees').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          List<Employee> employees = snapshot.data!.docs
              .map((doc) => Employee.fromFirestore(doc))
              .toList();

          return ListView.builder(
            itemCount: employees.length,
            itemBuilder: (context, index) {
              return EmployeeCard(employee: employees[index]);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AddEmployeePage()),
        ),
        child: Icon(Icons.add),
        backgroundColor: kGreenColor,
      ),
    );
  }
}

class EmployeeCard extends StatelessWidget {
  final Employee employee;

  const EmployeeCard({Key? key, required this.employee}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => EmployeeDetailPage(employee: employee)),
        ),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            gradient: LinearGradient(
              colors: [kGreenColor, kGreenColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: ListTile(
            contentPadding: EdgeInsets.all(16),
            leading: Hero(
              tag: 'employee-photo-${employee.id}',
              child: CircleAvatar(
                backgroundImage: NetworkImage(employee.photoUrl),
                radius: 30,
              ),
            ),
            title: Text(
              employee.name,
              style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold, color: Colors.white),
            ),
            subtitle: Text(
              '${employee.position}\nNIP: ${employee.nip}',
              style: GoogleFonts.poppins(color: Colors.white70),
            ),
            trailing: IconButton(
              icon: Icon(Icons.delete, color: Colors.white),
              onPressed: () => _deleteEmployee(context, employee.id),
            ),
          ),
        ),
      ),
    );
  }

  void _deleteEmployee(BuildContext context, String id) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Confirm Deletion"),
          content: Text("Are you sure you want to delete this employee?"),
          actions: [
            TextButton(
              child: Text("Cancel"),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text("Delete"),
              onPressed: () {
                FirebaseFirestore.instance
                    .collection('employees')
                    .doc(id)
                    .delete();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class AddEmployeePage extends StatefulWidget {
  @override
  _AddEmployeePageState createState() => _AddEmployeePageState();
}

class _AddEmployeePageState extends State<AddEmployeePage> {
  final _formKey = GlobalKey<FormState>();
  final _nameCon = TextEditingController();
  final _nipCon = TextEditingController();
  final _positionCon = TextEditingController();
  final _passwordCon = TextEditingController();
  ImageData? _imageData;
  bool _isLoading = false;

  Future<void> _getImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile =
        await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      if (kIsWeb) {
        // Handle web
        final bytes = await pickedFile.readAsBytes();
        setState(() {
          _imageData = ImageData(
            file: bytes,
            path: pickedFile.path,
            isWeb: true,
          );
        });
      } else {
        // Handle mobile
        setState(() {
          _imageData = ImageData(
            file: File(pickedFile.path),
            path: pickedFile.path,
            isWeb: false,
          );
        });
      }
    }
  }

  Future<String> _uploadImage() async {
    if (_imageData == null) return '';

    String fileName = const Uuid().v4();
    Reference ref =
        FirebaseStorage.instance.ref().child('employee_photos/$fileName.jpg');

    UploadTask uploadTask;
    if (_imageData!.isWeb) {
      // Upload for web
      uploadTask = ref.putData(_imageData!.file);
    } else {
      // Upload for mobile
      uploadTask = ref.putFile(_imageData!.file);
    }

    await uploadTask;
    return await ref.getDownloadURL();
  }

  void _saveEmployee() async {
    if (_formKey.currentState!.validate() && _imageData != null) {
      setState(() {
        _isLoading = true;
      });

      try {
        String photoUrl = await _uploadImage();
        String passwordHash =
            BCrypt.hashpw(_passwordCon.text, BCrypt.gensalt());

        await FirebaseFirestore.instance.collection('employees').add({
          'name': _nameCon.text,
          'nip': _nipCon.text,
          'photoUrl': photoUrl,
          'position': _positionCon.text,
          'passwordHash': passwordHash,
        });

        Navigator.pop(context);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving employee: ${e.toString()}')),
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Employee',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: kGreenColor,
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  GestureDetector(
                    onTap: _getImage,
                    child: Container(
                      height: 200,
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: _imageData != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(15),
                              child: _imageData!.isWeb
                                  ? Image.memory(_imageData!.file,
                                      fit: BoxFit.cover)
                                  : Image.file(_imageData!.file,
                                      fit: BoxFit.cover),
                            )
                          : const Icon(Icons.add_a_photo,
                              size: 50, color: Colors.grey),
                    ),
                  ),
                  // Rest of the form fields remain the same
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _nameCon,
                    decoration: InputDecoration(
                      labelText: 'Name',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    validator: (value) =>
                        value!.isEmpty ? 'Please enter a name' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _nipCon,
                    decoration: InputDecoration(
                      labelText: 'NIP',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    validator: (value) =>
                        value!.isEmpty ? 'Please enter NIP' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _positionCon,
                    decoration: InputDecoration(
                      labelText: 'Position',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    validator: (value) =>
                        value!.isEmpty ? 'Please enter a position' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _passwordCon,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    obscureText: true,
                    validator: (value) => value!.length < 6
                        ? 'Password must be at least 6 characters'
                        : null,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _saveEmployee,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kGreenColor,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: Text('Save Employee',
                        style: GoogleFonts.poppins(fontSize: 16)),
                  ),
                ],
              ),
            ),
          ),
          if (_isLoading)
            Container(
              color: Colors.black54,
              child: const Center(
                child: CircularProgressIndicator(),
              ),
            ),
        ],
      ),
    );
  }
}

class EmployeeDetailPage extends StatelessWidget {
  final Employee employee;

  const EmployeeDetailPage({Key? key, required this.employee})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            expandedHeight: 300.0,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(employee.name,
                  style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
              background: Hero(
                tag: 'employee-photo-${employee.id}',
                child: Image.network(
                  employee.photoUrl,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    _buildInfoCard('Position', employee.position),
                    SizedBox(height: 16),
                    _buildInfoCard('NIP', employee.nip),
                    // We don't display the password hash for security reasons
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(String title, String content) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: kGreenColor),
            ),
            SizedBox(height: 8),
            Text(
              content,
              style: GoogleFonts.poppins(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
