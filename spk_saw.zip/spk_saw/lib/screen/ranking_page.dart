import 'dart:math';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:spk_saw/theme.dart';

class RankingPage extends StatelessWidget {
  const RankingPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> excludedPositions = ['admin', 'supervisor', 'direktur'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Employee Ranking',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: kGreenColor,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('employees')
            .where('supervisorApproved', isEqualTo: true)
            .where('directorApproved', isEqualTo: true)
            // .where('nip',
            //     whereNotIn: ['admin', 'supervisor', 'direktur'])
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: \${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          // Filter manual untuk position
          List<Employee> employees = snapshot.data!.docs
              .map((doc) => Employee.fromFirestore(doc))
              .where((employee) =>
                  !excludedPositions.contains(employee.nip.toLowerCase()))
              .toList();

          if (employees.isEmpty) {
            return Center(
              child: Text(
                'Tidak ada data karyawan yang sudah diapprove',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
            );
          }

          List<ScoredEmployee> scoredEmployees = applySAW(employees);
          scoredEmployees.sort((a, b) => b.score.compareTo(a.score));

          return ListView.builder(
            itemCount: scoredEmployees.length,
            itemBuilder: (context, index) {
              return EmployeeRankCard(
                employee: scoredEmployees[index],
                rank: index + 1,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailRankingPage(
                          scoredEmployee: scoredEmployees[index]),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  List<ScoredEmployee> applySAW(List<Employee> employees) {
    final weights = [0.4, 0.3, 0.2, 0.1]; // C1, C2, C3, C4 weights
    List<ScoredEmployee> scoredEmployees = [];

    double maxC1 = employees.map((e) => e.productivity).reduce(max);
    double minC2 =
        employees.map((e) => normalizeViolation(e.violation)).reduce(min);

    for (var employee in employees) {
      double c1 = normalizeProductivity(employee.productivity) / 4;
      double c2 =
          minC2 / normalizeViolation(employee.violation); // Cost criteria
      double c3 = normalizeAttitude(employee.attitude) / 4;
      double c4 = normalizeCreativity(employee.creativity) / 4;

      double score = (c1 * weights[0] +
              c2 * weights[1] +
              c3 * weights[2] +
              c4 * weights[3]) *
          100;
      scoredEmployees.add(ScoredEmployee(
        employee: employee,
        score: score,
        normalizedScores: [c1, c2, c3, c4],
      ));
    }

    return scoredEmployees;
  }

  double normalizeProductivity(double value) {
    if (value <= 70) {
      return 1;
    } else if (value > 70 && value <= 80) {
      return 2;
    } else if (value > 80 && value <= 90) {
      return 3;
    } else {
      return 4;
    }
  }

  double normalizeViolation(String value) {
    switch (value) {
      case 'Tidak ada SP':
        return 1;
      case 'SP1':
        return 2;
      case 'SP2':
        return 3;
      case 'SP3':
        return 4;
      default:
        return 0;
    }
  }

  double normalizeAttitude(String value) {
    switch (value) {
      case 'Kurang':
        return 1;
      case 'Cukup':
        return 2;
      case 'Baik':
        return 3;
      case 'Sangat Baik':
        return 4;
      default:
        return 0;
    }
  }

  double normalizeCreativity(String value) {
    switch (value) {
      case 'Kurang':
        return 1;
      case 'Cukup':
        return 2;
      case 'Baik':
        return 3;
      case 'Sangat Baik':
        return 4;
      default:
        return 0;
    }
  }
}

class EmployeeRankCard extends StatelessWidget {
  final ScoredEmployee employee;
  final int rank;
  final VoidCallback onTap;

  const EmployeeRankCard(
      {Key? key,
      required this.employee,
      required this.rank,
      required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: rank <= 3 ? kGreenColor : Colors.white,
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
            backgroundColor: rank <= 3 ? kGreenColor : Colors.grey.shade200,
            child: Image.network(employee.employee.foto)
            //  Text(
            //   '\$rank',
            //   style: TextStyle(
            //     color: rank <= 3 ? Colors.white : Colors.black,
            //     fontWeight: FontWeight.bold,
            //   ),
            // ),
            ),
        title: Text(
          employee.employee.name,
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('Score: ${employee.score.toStringAsFixed(2)}'),
        trailing: Icon(
          Icons.star,
          color: rank == 1 ? Colors.amber : Colors.grey.shade400,
        ),
      ),
    );
  }
}

class DetailRankingPage extends StatelessWidget {
  final ScoredEmployee scoredEmployee;

  const DetailRankingPage({Key? key, required this.scoredEmployee})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ranking Detail',
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: kGreenColor,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(scoredEmployee.employee.foto),
            Text('Employee Profile',
                style: GoogleFonts.poppins(
                    fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            _buildProfileCard(),
            SizedBox(height: 24),
            Text('Criteria Scores',
                style: GoogleFonts.poppins(
                    fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            _buildCriteriaScores(),
            SizedBox(height: 24),
            Text('SAW Calculation',
                style: GoogleFonts.poppins(
                    fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            _buildSAWCalculation(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Name: ${scoredEmployee.employee.name}',
                style: GoogleFonts.poppins(fontSize: 18)),
            Text('Final Score: ${scoredEmployee.score.toStringAsFixed(2)}',
                style: GoogleFonts.poppins(
                    fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildCriteriaScores() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Productivity: ${scoredEmployee.employee.productivity}%',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text('Violation: ${scoredEmployee.employee.violation}',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text('Attitude: ${scoredEmployee.employee.attitude}',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text('Creativity: ${scoredEmployee.employee.creativity}',
                style: GoogleFonts.poppins(fontSize: 16)),
          ],
        ),
      ),
    );
  }

  Widget _buildSAWCalculation() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Normalization:',
                style: GoogleFonts.poppins(
                    fontSize: 18, fontWeight: FontWeight.bold)),
            Text(
                'C1 (Productivity) = ${scoredEmployee.normalizedScores[0].toStringAsFixed(4)}',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text(
                'C2 (Violation) = ${scoredEmployee.normalizedScores[1].toStringAsFixed(4)}',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text(
                'C3 (Attitude) = ${scoredEmployee.normalizedScores[2].toStringAsFixed(4)}',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text(
                'C4 (Creativity) = ${scoredEmployee.normalizedScores[3].toStringAsFixed(4)}',
                style: GoogleFonts.poppins(fontSize: 16)),
            SizedBox(height: 16),
            Text('Weighted Sum:',
                style: GoogleFonts.poppins(
                    fontSize: 18, fontWeight: FontWeight.bold)),
            Text('(0.4 * C1) + (0.3 * C2) + (0.2 * C3) + (0.1 * C4)',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text(
                '= (0.4 * ${scoredEmployee.normalizedScores[0].toStringAsFixed(4)}) + (0.3 * ${scoredEmployee.normalizedScores[1].toStringAsFixed(4)}) + (0.2 * ${scoredEmployee.normalizedScores[2].toStringAsFixed(4)}) + (0.1 * ${scoredEmployee.normalizedScores[3].toStringAsFixed(4)})',
                style: GoogleFonts.poppins(fontSize: 16)),
            Text('= ${scoredEmployee.score.toStringAsFixed(4)}',
                style: GoogleFonts.poppins(
                    fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class Employee {
  final String id;
  final String name;
  final String nip;
  final double productivity;
  final String violation;
  final String attitude;
  final String creativity;
  final String foto;

  Employee({
    required this.id,
    required this.name,
    required this.nip,
    required this.productivity,
    required this.violation,
    required this.attitude,
    required this.creativity,
    required this.foto,
  });

  factory Employee.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Employee(
      id: doc.id,
      name: data['name'] ?? '',
      nip: data['nip'] ?? '',
      productivity: (data['productivity'] ?? 0).toDouble(),
      violation: data['violation'] ?? 'Tidak ada SP',
      attitude: data['attitude'] ?? 'Cukup',
      creativity: data['creativity'] ?? 'Cukup',
      foto: data['photoUrl'] ?? '',
    );
  }
}

class ScoredEmployee {
  final Employee employee;
  final double score;
  final List<double> normalizedScores;

  ScoredEmployee(
      {required this.employee,
      required this.score,
      required this.normalizedScores});
}
