import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spk_saw/theme.dart';
import 'package:bcrypt/bcrypt.dart';

import '../home.dart';
import 'admin_page.dart';
import 'assesmen_atasan.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nipController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _isPasswordVisible = false;

  Future<void> _handleLogin() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Cek credentials di Firestore
        final userSnapshot = await FirebaseFirestore.instance
            .collection('employees')
            .where('nip', isEqualTo: _nipController.text)
            .get();

        if (userSnapshot.docs.isEmpty) {
          setState(() {
            _isLoading = false;
          });
          _showError('NIP tidak ditemukan');
          return;
        }

        final userData = userSnapshot.docs.first.data();
        final String hashedPassword = userData['passwordHash'] as String;

        // Verify password using BCrypt
        final bool isPasswordValid = BCrypt.checkpw(
          _passwordController.text,
          hashedPassword,
        );

        if (!isPasswordValid) {
          setState(() {
            _isLoading = false;
          });
          _showError('Password salah');
          return;
        }

        // Save user data to SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('nip', _nipController.text);
        await prefs.setString('name', userData['name'] ?? '');
        await prefs.setString('position', userData['position'] ?? '');

        setState(() {
          _isLoading = false;
        });

        // Navigate based on position
        _navigateBasedOnRole(_nipController.text);
      } catch (e) {
        setState(() {
          _isLoading = false;
        });
        _showError('Terjadi kesalahan: $e');
      }
    }
  }

  void _navigateBasedOnRole(String nip) {
    // Remove all previous routes
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) {
          if (nip == 'admin') {
            return AdminPage();
          } else if (nip == 'supervisor' || nip == 'direktur') {
            return AssessmentAtasan(userNIP: nip);
          } else {
            return UserPage();
          }
        },
      ),
      (route) => false, // Remove all previous routes
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(height: 60),
                  // Logo or Image
                  Image.asset(
                    'assets/logobankjogja.png', // Sesuaikan dengan path logo Anda
                    height: 150,
                  ),
                  SizedBox(height: 40),
                  Text(
                    'Employee Assessment',
                    style: GoogleFonts.poppins(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: kGreenColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 40),
                  // NIP Field
                  TextFormField(
                    controller: _nipController,
                    decoration: InputDecoration(
                      labelText: 'NIP',
                      prefixIcon: Icon(Icons.person),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: kGreenColor),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'NIP tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 16),
                  // Password Field
                  TextFormField(
                    controller: _passwordController,
                    obscureText: !_isPasswordVisible,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _isPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                        ),
                        onPressed: () {
                          setState(() {
                            _isPasswordVisible = !_isPasswordVisible;
                          });
                        },
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: kGreenColor),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Password tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 24),
                  // Login Button
                  ElevatedButton(
                    onPressed: _isLoading ? null : _handleLogin,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kGreenColor,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: _isLoading
                        ? SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            'Login',
                            style: GoogleFonts.poppins(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nipController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
