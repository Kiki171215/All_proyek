part of 'datauser_bloc.dart';

@immutable
abstract class DatauserEvent {}

class DatauserEventFetch extends DatauserEvent {
  final String name, email, nohp, role, foto;
  DatauserEventFetch({
    required this.name,
    required this.email,
    required this.nohp,
    required this.role,
    required this.foto,
  });
}
