part of 'datauser_bloc.dart';

@immutable
abstract class DatauserState {
  final String name, email, nohp, role, foto;

  const DatauserState(
    this.name,
    this.email,
    this.nohp,
    this.role,
    this.foto,
  );
}

class DatauserInitial extends DatauserState {
  DatauserInitial()
      : super("sample name", "sample email", 'sample no', 'user', 'foto');
}

class DatauserLoad extends DatauserState {
  const DatauserLoad(
      String name, String email, String nohp, String role, String foto)
      : super(name, email, nohp, role, foto);
}
