import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
// Hapus import flutter_riverpod jika tidak digunakan
// import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:spk_saw/screen/admin_page.dart';
import 'package:spk_saw/screen/login_page.dart';

import 'bloc/Islogin/islogin_bloc.dart';
import 'bloc/activeindexwebmenu/activeindexwebmenu_bloc.dart';
import 'bloc/datauser/datauser_bloc.dart';
import 'bloc/isloadinglogin/isloadinglogin_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    if (kIsWeb) {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyCRDB2Jd10gvlhnBM_kZatY41cQtEVfF4I",
            authDomain: "spk-saw-a33b7.firebaseapp.com",
            projectId: "spk-saw-a33b7",
            storageBucket: "spk-saw-a33b7.appspot.com",
            messagingSenderId: "1083972676148",
            appId: "1:1083972676148:web:b45a7b2da7757452e07861"),
      );
    } else {
      await Firebase.initializeApp();
    }
    print("Firebase initialized successfully");
  } catch (e) {
    print("Error initializing Firebase: $e");
  }
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // Tambahkan BlocProviders Anda
        BlocProvider(
          create: (context) => IsloadingloginBloc(),
        ),
        BlocProvider(
          create: (context) => IsloginBloc(),
        ),
        BlocProvider(
          create: (context) => DatauserBloc(),
        ),
        BlocProvider(
          create: (context) => ActiveindexwebmenuBloc(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'SPK SAW Bank Jogja',
        theme: ThemeData(
          primarySwatch: Colors.green,
          textTheme: GoogleFonts
              .poppinsTextTheme(), // Menggunakan Google Fonts untuk tipografi yang menarik
        ),
        home: const LoginPage(), // Ganti dengan halaman utama Anda
      ),
    );
  }
}
